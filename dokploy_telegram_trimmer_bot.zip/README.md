# Telegram Video Trimmer Bot

Deployable via Dokploy with Dockerfile.
